package com.nnh.model.dto;

public class CityDTO extends AbstractDTO<CityDTO>{
}
