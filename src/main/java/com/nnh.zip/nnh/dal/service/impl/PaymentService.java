package com.nnh.dal.service.impl;

import org.springframework.stereotype.Service;

import com.nnh.dal.service.IPaymentService;

@Service
public class PaymentService implements IPaymentService{

}
