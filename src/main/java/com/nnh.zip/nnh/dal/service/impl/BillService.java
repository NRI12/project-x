package com.nnh.dal.service.impl;

import org.springframework.stereotype.Service;

import com.nnh.dal.service.IBillService;

@Service
public class BillService implements IBillService{

}
