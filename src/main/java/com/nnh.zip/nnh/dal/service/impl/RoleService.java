package com.nnh.dal.service.impl;

import org.springframework.stereotype.Service;

import com.nnh.dal.service.IRoleService;

@Service
public class RoleService implements IRoleService{

}
