package com.nnh.dal.service.impl;

import org.springframework.stereotype.Service;

import com.nnh.dal.service.ICountryService;

@Service
public class CountryService implements ICountryService{

}
